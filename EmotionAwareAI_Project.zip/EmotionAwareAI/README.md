# Emotion-Aware Multimodal AI for Mental Health Forecasting

This project implements the model described in the research paper:
**"Emotion-Aware Multimodal AI for Mental Health Forecasting"**

## Setup
```
pip install -r requirements.txt
```

## Run Training
```
python main.py --train
```

## Folder Structure
- models/: BERT, CNN, MLP, Fusion architectures
- data/: Dataset loaders and preprocessing
- utils/: Helper scripts for metrics and reproducibility
- checkpoints/: Saved model checkpoints
